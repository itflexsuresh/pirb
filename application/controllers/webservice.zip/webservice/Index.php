<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Index extends CI_Controller 
{
	public function __construct()
	{
		parent::__construct();
		$this->load->model('Coc_Model');
		$this->load->model('Coc_Ordermodel');
		$this->load->model('Auditor_Model');
		$this->load->model('Friends_Model');
		$this->load->model('Chat_Model');
		//$this->load->model('Ratings_Model');

		$this->load->model('CC_Model');
		$this->load->model('Users_Model');
		$this->load->model('Company_Model');
		$this->load->model('Installationtype_Model');
		$this->load->model('Managearea_Model');
		$this->load->model('Qualificationroute_Model');
		$this->load->model('Rates_Model');
		$this->load->model('Comment_Model');
		$this->load->model('Systemsettings_Model');
		$this->load->model('Auditor_Model');
		//$this->load->model('Coc_Model');
		$this->load->model('Coc_Ordermodel');
		$this->load->model('Communication_Model');
		$this->load->model('Plumber_Model');
		$this->load->model('Paper_Model');
		$this->load->model('Noncompliance_Model');
		$this->load->model('Auditor_Reportlisting_Model');
		$this->load->model('Global_performance_Model');
		$this->load->model('Auditor_Comment_Model');
		$this->load->model('Diary_Model');
		$this->load->model('Resellers_Model');
		$this->load->model('Resellers_allocatecoc_Model');
		$this->load->model('Plumberperformance_Model');
	}
	
	public function plumber_dashboard($plumberID=0)
	{
		$jsonData = [];
		$id 										= $plumberID;
		$userdata 									= $this->getUserDetails($plumberID);

		$jsonData['id'] 							= $plumberID;
		$jsonData['userdata'] 						= $this->getUserDetails($plumberID);
		
		$jsonData['mycpd'] 							= $this->userperformancestatus(['performancestatus' => '1', 'auditorstatement' => '1'], $id);
		$jsonData['nonlogcoc']						= $this->Coc_Model->getCOCList('count', ['user_id' => $id, 'coc_status' => ['4','5']]);
		$jsonData['adminstock'] 					= $this->Coc_Ordermodel->getCocorderList('all', ['admin_status' => '0', 'userid' => $id]);
		$jsonData['adminstock']						= array_sum(array_column($jsonData['adminstock'], 'quantity'));
		$jsonData['coccount']						= $this->Coc_Model->COCcount(['user_id' => $id]);
		$jsonData['coccount']						= $jsonData['coccount']['count'];
		
		$jsonData['history']						= $this->Auditor_Model->getReviewHistoryCount(['plumberid' => $id]);
		$jsonData['auditcoc'] 						= $jsonData['history']['total'];
		$jsonData['auditrefixincomplete'] 			= $jsonData['history']['refixincomplete'];
		$jsonData['auditorratio']					= $this->Auditor_Model->getAuditorRatio('row', ['userid' => $id]);
		$jsonData['auditorratio']					= ($jsonData['auditorratio']) ? $jsonData['auditorratio']['audit'].'%' : '0%';
		
		$jsonData['myprovinceperformancestatus'] 	= $this->userperformancestatus(['province' => $userdata['province']], $id);
		$jsonData['performancestatus'] 				= $this->userperformancestatus();
		$jsonData['mycityperformancestatus'] 		= $this->userperformancestatus(['city' => $userdata['city']], $id);
		$jsonData['provinceperformancestatus'] 		= $this->userperformancestatus(['province' => $userdata['province'], 'limit' => '3'], $id);
		$jsonData['cityperformancestatus'] 			= $this->userperformancestatus(['city' => $userdata['city'], 'limit' => '3'],$id);
		
		$friends 									= $this->Friends_Model->getList('all', ['userid' => $id, 'fromto' => $id, 'status' => ['1'], 'limit' => '10']);
		$friendsarray								= [];
		if(count($friends) > 0){
			foreach($friends as $friend){
				$friendperformance = $this->userperformancestatus(['userid' => $friend['userid']]);
				$friendsarray[] =  $friend+['rank' => $friendperformance];
			}
			
			array_multisort(array_column($friendsarray, 'rank'), SORT_ASC, $friendsarray);
		}
		
		$jsonData['friends'] 						= $friendsarray;

		$jsonData['chat_count'] 					= $this->Chat_Model->getList('count',['to_id' => $id, 'msg_status' => '0']);
		$jsonData['chat_messages'] 					= $this->Chat_Model->getList('all',['to_id' => $id, 'msg_status' => '0']);

		//$jsonData['chat_users'] 					= $this->Chat_Model->getChatUsers();

		$encodeData 								= json_encode($jsonData);
		$decodeData 								= json_decode($encodeData);

		
		echo $encodeData;
		//echo "<pre>";
		//print_r($decodeData);
		//die;
	}


	// Get user details:
	public function getUserDetails($id='')
	{
		if($id!=''){
			$userid = $id;
		}
		// elseif($this->session->has_userdata('userid')){
		// 	$userid = $this->session->userdata('userid');
		// }
		
		if(isset($userid)){
			$result = $this->Users_Model->getUserDetails('row', ['id' => $userid, 'status' => ['0','1']]);
			
			if($result){
				return $result;
			}else{
				return '';
			}
		}else{
			return '';
		}
	}

	public function userperformancestatus($data = [], $id=''){	
		//print_r($data);die;
		$rollingavg 	= $this->getRollingAverage();
		$userid			= (isset($data['userid'])) ? $data['userid'] : $id;
		$date			= date('Y-m-d', strtotime(date('Y-m-d').'+'.$rollingavg.' months'));
		
		$extradata 				= $data;
		$extradata['date'] 		= $date;
		$extradata['archive'] 	= '0';
		
		if(count($data)==0){
			$extradata['plumberid'] = $userid;
		}elseif(count($data) > 0 && in_array('performancestatus', array_keys($data))){
			//print_r($data);die;
			unset($extradata['date']);
			unset($extradata['archive']);
			$extradata['plumberid'] = $userid;
			unset($data);
		}
		
		$results = $this->Plumber_Model->performancestatus('all', $extradata);
		
		if(isset($data) && count($data) > 0){
			if(isset($data['limit'])) return $results;
			else return array_search($userid, array_column($results, 'userid'))+1;
		}else{
			return count($results) ? array_sum(array_column($results, 'point')) : '0';
		}
	}

	public function getRollingAverage()
	{
		return $this->getAuditorPoints($this->config->item('rollingaverage'));
	}

	public function getAuditorPoints($id)
	{
		$data = $this->Global_performance_Model->getPointList('row', ['id' => $id]);
		
		if($data) return $data['point'];
		else return '';
	}


	// Plumber Registration:

	public function plumber_registration($plumberID=0)
	{
		$jsonData = [];

		$result		= 	$this->Plumber_Model->getList('row', ['id' => $plumberID, 'status' => ['0','1']], ['users', 'usersdetail', 'usersplumber', 'usersskills', 'company', 'physicaladdress', 'postaladdress', 'billingaddress']);
		
		if (is_array($result) && count($result) > 0) {
			
			$jsonData['result'] 			= $result;

		}else{

			$jsonData['result'] 			= 'No data try again';
		}
		
		$jsonData['province'] 			= $this->getProvinceList();
		$jsonData['qualificationroute'] = $this->getQualificationRouteList();
		$jsonData['plumberrates'] 		= $this->getPlumberRates();
		$jsonData['company'] 			= $this->getCompanyList();




		$encodeData 								= json_encode($jsonData);
		$decodeData 								= json_decode($encodeData);

		echo $encodeData;
		//echo "<pre>";
		//print_r($decodeData);
		//die;
	}

	public function plumber_registration_action()
	{
		$post 				= $this->input->post();
		// Send user Id as hidden durring ajax call
		//$post['user_id'] 	= $this->getUserID();
		$result = $this->Plumber_Model->action($post);
		
		if($result){
			$json = ['status' => '1', 'result' => $post];
		}else{
			$json = ['status' => '0', 'result' => 'Something Went wrong please try again!'];
		}

		$encodeData 								= json_encode($post);
		$decodeData 								= json_decode($encodeData);
		
		echo $encodeData;
		//echo "<pre>";
		//print_r($decodeData);
		//die;
	}



	public function getProvinceList()
	{
		$data = $this->Managearea_Model->getListProvince('all', ['status' => ['1']]);
		
		if(count($data) > 0) return ['' => 'Select Province']+array_column($data, 'name', 'id');
		else return [];
	}

	public function getQualificationRouteList()
	{
		$data = $this->Qualificationroute_Model->getList('all', ['status' => ['1']]);
		
		if(count($data) > 0) return ['' => 'Select Qualification Route']+array_column($data, 'name', 'id');
		else return [];
	}

	public function getCompanyList()
	{
		$data = $this->Company_Model->getList('all', ['type' => '4', 'status' => ['1'], 'companystatus' => ['1']], ['users', 'usersdetail']);
		
		if(count($data) > 0) return ['' => 'Select Company']+array_column($data, 'company', 'id');
		else return [];
	}

	public function getPlumberRates()
	{
		return 	[
			'1' => $this->getRates($this->config->item('learner')),
			'2' => $this->getRates($this->config->item('assistant')),
			'3' => $this->getRates($this->config->item('operator')),
			'4' => $this->getRates($this->config->item('licensed'))
		];
	}

	public function getRates($id)
	{
		$data = $this->Rates_Model->getList('row', ['id' => $id, 'status' => ['1']]);
		
		if($data) return $data['amount'];
		else return '';
	}


	// Plumber COCs
	public function plumber_COC($plumberID=0)
	{
		$jsonData = [];

		$userid 					=	$plumberID;
		$userdata					= 	$this->getUserDetails($userid);
		$userdata1					= 	$this->Plumber_Model->getList('row', ['id' => $userid], ['users', 'usersdetail', 'usersplumber']);
		$userdatacoc_count			= 	$this->Coc_Model->COCcount(['user_id' => $userid]);
		$jsonData['province'] 		= 	$this->getProvinceList();
		$jsonData['userid']			= 	$userid;
		$jsonData['userdata']		= 	$userdata;
		$jsonData['userdata1']		= 	$userdata1;
		$jsonData['coc_count']		= 	$userdatacoc_count;

		$jsonData['deliverycard']	= 	$this->config->item('purchasecocdelivery');
		$jsonData['coctype']		= 	$this->config->item('coctype');
		$jsonData['settings']		= 	$this->Systemsettings_Model->getList('row');
		$jsonData['logcoc']			=	$this->Coc_Model->getCOCList('count', ['user_id' => $userid, 'coc_status' => ['4','5']]);
		$jsonData['cocpaperwork']	=	$this->Rates_Model->getList('row', ['id' => $this->config->item('cocpaperwork')]);
		$jsonData['cocelectronic']	=	$this->Rates_Model->getList('row', ['id' => $this->config->item('cocelectronic')]);
		$jsonData['postage']		= 	$this->Rates_Model->getList('row', ['id' => $this->config->item('postage')]);
		$jsonData['couriour']		= 	$this->Rates_Model->getList('row', ['id' => $this->config->item('couriour')]);
		$jsonData['collectedbypirb']= 	$this->Rates_Model->getList('row', ['id' => $this->config->item('collectedbypirb')]);
		$orderquantity 				= $this->Coc_Ordermodel->getCocorderList('all', ['admin_status' => '0', 'userid' => $userid]);
		$jsonData['userorderstock']	= array_sum(array_column($orderquantity, 'quantity'));


		$encodeData 								= json_encode($jsonData);
		$decodeData 								= json_decode($encodeData);

		echo $encodeData;
		//echo "<pre>";
		//print_r($decodeData);
		//die;
	}

	public function coc_statement($plumberID=0){

		$jsonData = [];

		$userid 				= $plumberID;
		$post 					= 'api_call';
		$jsonData['totalcount'] = $this->Coc_Model->getCOCList('count', ['user_id' => $userid, 'coc_status' => ['2','4','5','7'], 'page' => $post]);
		$jsonData['results'] 	= $this->Coc_Model->getCOCList('all', ['user_id' => $userid, 'coc_status' => ['2','4','5','7'],'page' => $post]);

		$encodeData 								= json_encode($jsonData);
		$decodeData 								= json_decode($encodeData);

		echo $encodeData;
		//echo "<pre>";
		//print_r($decodeData);
		
	}

	public function logcocget($plumberID=0, $cocId=0){

		$jsonData = [];

		$result = $this->coclogaction(
			$cocId, 
			['pagetype' => 'view', 'roletype' => $this->config->item('roleplumber'), 'electroniccocreport' => 'plumber/cocstatement/index/electroniccocreport/'.$cocId, 'noncompliancereport' => 'plumber/cocstatement/index/noncompliancereport/'.$cocId], 
			['redirect' => 'plumber/cocstatement/index', 'userid' => $plumberID]
		);

		if (is_array($result) && count($result) > 0 && !empty($result['result']['cl_id'])) {
			
			$jsonData['coc_data'] 			= $result;

		}else{

			$jsonData['coc_data'] 			= 'No data try again';
		}

		$encodeData 								= json_encode($jsonData);
		$decodeData 								= json_decode($encodeData);

		echo $encodeData;
		// echo "<pre>";
		// print_r($decodeData);
		
	}



	public function coclogaction($id, $pagedata=[], $extras=[])
	{
		$userid							= $extras['userid'];
		$auditorid						= isset($extras['auditorid']) ? ['auditorid' => $extras['auditorid']] : [];
		$result							= $this->Coc_Model->getCOCList('row', ['id' => $id, 'user_id' => $userid]+$auditorid);
		// if(!$result){
		// 	$this->session->set_flashdata('error', 'No Record Found.');
		// 	redirect($extras['redirect']); 
		// }
		
		$userdata				 		= $this->Plumber_Model->getList('row', ['id' => $userid], ['users', 'usersdetail', 'usersplumber', 'company']);
		$specialisations 				= explode(',', $userdata['specialisations']);
		
		
		
		$pagedata['userdata'] 			= $userdata;
		$pagedata['cocid'] 				= $id;
		
		$pagedata['province'] 			= $this->getProvinceList();
		$pagedata['designation2'] 		= $this->config->item('designation2');
		$pagedata['ncnotice'] 			= $this->config->item('ncnotice');
		$pagedata['installationtype']	= $this->getInstallationTypeList();
		$pagedata['installation'] 		= $this->Installationtype_Model->getList('all', ['designation' => $userdata['designation'], 'specialisations' => [], 'ids' => range(1,8)]);
		$pagedata['specialisations']	= $this->Installationtype_Model->getList('all', ['designation' => $userdata['designation'], 'specialisations' => $specialisations, 'ids' => range(1,8)]);
		$pagedata['result']				= $result;
		
		$noncompliance					= $this->Noncompliance_Model->getList('all', ['coc_id' => $id, 'user_id' => $userid]);		
		$pagedata['noncompliance']		= [];
		foreach($noncompliance as $compliance){
			$pagedata['noncompliance'][] = [
				'id' 		=> $compliance['id'],
				'details' 	=> $this->parsestring($compliance['details']),
				'file' 		=> $compliance['file']
			];
		}
		
		return $pagedata;
	}

	public function getInstallationTypeList()
	{
		$data = $this->Installationtype_Model->getList('all', ['status' => ['1']]);
		
		if(count($data) > 0) return ['' => 'Select Installation Type']+array_column($data, 'name', 'id');
		else return [];
	}

	function parsestring($text) {
		$text = str_replace("\r\n", "\n", $text);
		$text = str_replace("\r", "\n", $text);

		$text = str_replace("\n", "\\n", $text);
		return $text;
	}

	
}
