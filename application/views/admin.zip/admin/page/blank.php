
			   
			     <!-- .row -->
               <div class="row">
                  <div class="col-md-12">
                     <div class="white-box">
                        <h3 class="box-title">Blank Starter page</h3>
                     </div>
                  </div>
               </div>
               <!-- .row -->