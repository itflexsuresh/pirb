            <footer class="footer text-center"><i class="fa fa-globe"></i> Optimum Footer<?php // echo $footer;?>&nbsp; <i class="fa fa-globe"></i> </footer>
